import os
import joblib
import streamlit as st

from train_model import FEATURES, train

st.set_page_config(page_title="House Price Predictor", page_icon="🏠")
st.title("🏠 House Price Predictor")
st.caption("Linear Regression model trained on sample data")

MODEL_PATH = "house_model.pkl"


@st.cache_resource
def load_model():
    if not os.path.exists(MODEL_PATH):
        train()  # train automatically if model file is missing
    return joblib.load(MODEL_PATH)


model = load_model()

col1, col2 = st.columns(2)
with col1:
    area = st.number_input("Area (sq ft)", 500, 4000, 1500, step=50)
    bedrooms = st.slider("Bedrooms", 1, 5, 3)
    bathrooms = st.slider("Bathrooms", 1, 4, 2)
with col2:
    age = st.slider("Age of house (years)", 0, 40, 5)
    location = st.slider("Location score (1 = poor, 10 = prime)", 1, 10, 6)

if st.button("Predict Price", type="primary"):
    values = [[area, bedrooms, bathrooms, age, location]]
    price = model.predict(values)[0]
    st.success(f"Estimated price: ₹ {price:,.2f} lakhs")

with st.expander("Model coefficients"):
    for name, coef in zip(FEATURES, model.coef_):
        st.write(f"**{name}**: {coef:.3f}")
    st.write(f"**intercept**: {model.intercept_:.3f}")
