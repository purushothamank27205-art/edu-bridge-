"""Central configuration (paths, features, seeds). Override via env vars."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DATA_PATH = DATA_DIR / "housing.csv"
DATA_INFO_PATH = DATA_DIR / "DATASET_INFO.json"
MODELS_DIR = ROOT / "models"
MODEL_PATH = Path(os.getenv("MODEL_PATH", MODELS_DIR / "model.joblib"))
MODEL_META_PATH = Path(os.getenv("MODEL_META_PATH", MODELS_DIR / "model_metadata.json"))
FIG_DIR = ROOT / "reports" / "figures"
METRICS_DIR = ROOT / "reports" / "metrics"

SEED = 42
TARGET = "MedHouseVal"  # median house value, units of $100,000
FEATURES = ["MedInc", "HouseAge", "AveRooms", "AveBedrms",
            "Population", "AveOccup", "Latitude", "Longitude"]
FEATURE_DESCRIPTIONS = {
    "MedInc": "Median income in block group (units of $10,000)",
    "HouseAge": "Median house age in block group (years)",
    "AveRooms": "Average number of rooms per household",
    "AveBedrms": "Average number of bedrooms per household",
    "Population": "Block group population",
    "AveOccup": "Average household occupancy",
    "Latitude": "Block group latitude",
    "Longitude": "Block group longitude",
}
MLFLOW_EXPERIMENT = "house-price-prediction"
REGISTERED_MODEL_NAME = "house-price-model"
MLFLOW_DB = ROOT / "mlflow.db"
MLFLOW_ARTIFACTS = ROOT / "mlruns"
