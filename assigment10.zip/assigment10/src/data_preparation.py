"""Obtain + validate the dataset. Idempotent: skips download if valid file exists.

Real source: California Housing (Pace & Barry, 1997) via scikit-learn's
fetch_california_housing (downloads from figshare). If the network is
unavailable, a CLEARLY LABELLED synthetic dataset is generated as a last resort
and DATASET_INFO.json records `is_synthetic: true`.
"""
import argparse
import json
import sys
from datetime import date

import numpy as np
import pandas as pd

from src.config import (DATA_DIR, DATA_INFO_PATH, DATA_PATH, FEATURES,
                        FEATURE_DESCRIPTIONS, SEED, TARGET)

SOURCE_URL = "https://ndownloader.figshare.com/files/5976036"


def fetch_real() -> pd.DataFrame:
    from sklearn.datasets import fetch_california_housing
    ds = fetch_california_housing(data_home=str(DATA_DIR / "raw"), as_frame=True)
    return ds.frame[FEATURES + [TARGET]]


def make_synthetic(n: int = 6000, seed: int = SEED) -> pd.DataFrame:
    """Synthetic stand-in with the same schema (NOT real data)."""
    rng = np.random.default_rng(seed)
    inc = np.clip(rng.lognormal(1.25, 0.5, n), 0.5, 15)
    age = rng.integers(1, 53, n).astype(float)
    rooms = np.clip(rng.normal(5.4, 1.2, n), 2, 12)
    bed = np.clip(rooms * rng.normal(0.2, 0.03, n), 0.8, 4)
    pop = np.clip(rng.lognormal(7.1, 0.6, n), 50, 8000).round()
    occ = np.clip(rng.normal(3.0, 0.7, n), 1, 8)
    lat = rng.uniform(32.5, 42.0, n)
    lon = rng.uniform(-124.3, -114.3, n)
    coast = np.exp(-((lon + 122) ** 2 + (lat - 37.5) ** 2) / 8)
    y = (0.45 * inc + 0.004 * age + 0.08 * rooms - 0.1 * occ + 1.2 * coast
         + rng.normal(0, 0.35, n))
    y = np.clip(y, 0.15, 5.0)
    return pd.DataFrame({"MedInc": inc, "HouseAge": age, "AveRooms": rooms,
                         "AveBedrms": bed, "Population": pop, "AveOccup": occ,
                         "Latitude": lat, "Longitude": lon, TARGET: y})


def validate(df: pd.DataFrame) -> dict:
    missing_cols = [c for c in FEATURES + [TARGET] if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing columns: {missing_cols}")
    if len(df) < 1000:
        raise ValueError(f"Too few rows: {len(df)}")
    if not all(pd.api.types.is_numeric_dtype(df[c]) for c in FEATURES + [TARGET]):
        raise ValueError("Non-numeric column found")
    return {
        "rows": int(len(df)), "columns": int(df.shape[1]),
        "missing_values": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "target_describe": {k: float(v) for k, v in df[TARGET].describe().items()},
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
    }


def prepare(force: bool = False, synthetic: bool = False) -> pd.DataFrame:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if DATA_PATH.exists() and DATA_INFO_PATH.exists() and not force:
        df = pd.read_csv(DATA_PATH)
        validate(df)
        print(f"[data] Using existing {DATA_PATH} ({len(df)} rows)")
        return df
    is_synth, note = False, ""
    if synthetic:
        df, is_synth, note = make_synthetic(), True, "Synthetic requested explicitly."
    else:
        try:
            df = fetch_real()
        except Exception as exc:  # no network etc.
            print(f"[data] WARNING: real download failed ({type(exc).__name__}: "
                  f"{str(exc)[:100]}). Generating SYNTHETIC data instead.", file=sys.stderr)
            df, is_synth = make_synthetic(), True
            note = "Real download failed; synthetic fallback used. Not real-world data."
    report = validate(df)
    df.to_csv(DATA_PATH, index=False)
    info = {
        "name": "California Housing" if not is_synth else "SYNTHETIC California-Housing-like data",
        "is_synthetic": is_synth, "note": note,
        "source": "scikit-learn fetch_california_housing (StatLib / Pace & Barry 1997)",
        "download_url": SOURCE_URL,
        "license": "Public domain / freely redistributable (StatLib)",
        "collection_date": date.today().isoformat(),
        "target": TARGET, "target_units": "$100,000",
        "features": FEATURE_DESCRIPTIONS, "validation": report,
    }
    DATA_INFO_PATH.write_text(json.dumps(info, indent=2))
    print(f"[data] Saved {DATA_PATH} | synthetic={is_synth} | rows={len(df)}")
    return df


def load_data() -> pd.DataFrame:
    return prepare()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--synthetic", action="store_true")
    a = ap.parse_args()
    prepare(force=a.force, synthetic=a.synthetic)
