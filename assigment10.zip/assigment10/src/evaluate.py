"""Metrics + evaluation plots."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.config import FIG_DIR, METRICS_DIR


def regression_metrics(y_true, y_pred) -> dict:
    return {"mae": float(mean_absolute_error(y_true, y_pred)),
            "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
            "r2": float(r2_score(y_true, y_pred))}


def plot_predictions(y_true, y_pred, name: str):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ax[0].scatter(y_true, y_pred, s=6, alpha=0.4)
    lim = [min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())]
    ax[0].plot(lim, lim, "r--"); ax[0].set(xlabel="Actual", ylabel="Predicted", title=f"{name}: test actual vs predicted")
    ax[1].hist(np.asarray(y_true) - np.asarray(y_pred), bins=50)
    ax[1].set(title="Test residuals", xlabel="Actual - predicted")
    fig.tight_layout(); path = FIG_DIR / "eval_best_model.png"
    fig.savefig(path, dpi=110); plt.close(fig)
    return path


def save_results(results: dict, path=None):
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    path = path or METRICS_DIR / "model_comparison.json"
    path.write_text(json.dumps(results, indent=2))
    return path


if __name__ == "__main__":
    p = METRICS_DIR / "model_comparison.json"
    r = json.loads(p.read_text())
    print(f"Best model: {r['best_model']} (selected on validation {r['selection_metric']})")
    for n, m in r["models"].items():
        print(f"{n:22s} val_rmse={m['val']['rmse']:.4f} test_rmse={m['test']['rmse']:.4f} test_r2={m['test']['r2']:.4f}")
