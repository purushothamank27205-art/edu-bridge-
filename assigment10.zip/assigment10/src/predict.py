"""Standalone inference (no MLflow server needed)."""
import json
from pathlib import Path
from typing import Dict, List

import joblib
import pandas as pd

from src.config import FEATURES, MODEL_META_PATH, MODEL_PATH


class HousePredictor:
    def __init__(self, model_path: Path = MODEL_PATH, meta_path: Path = MODEL_META_PATH):
        self.pipeline = joblib.load(model_path)
        self.metadata = json.loads(Path(meta_path).read_text()) if Path(meta_path).exists() else {}

    def predict(self, records: List[Dict[str, float]]) -> List[float]:
        df = pd.DataFrame(records)[FEATURES]  # enforce feature order
        return [float(p) for p in self.pipeline.predict(df)]


if __name__ == "__main__":
    sample = {"MedInc": 5.0, "HouseAge": 20, "AveRooms": 5.5, "AveBedrms": 1.0,
              "Population": 1200, "AveOccup": 3.0, "Latitude": 37.8, "Longitude": -122.3}
    print(HousePredictor().predict([sample]))
