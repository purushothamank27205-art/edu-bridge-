"""Train baseline + candidate models, track (MLflow if installed), select, save."""
import json
import platform
from datetime import datetime, timezone

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import sklearn
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src import config as C
from src.data_preparation import load_data
from src.evaluate import plot_predictions, regression_metrics, save_results

SELECTION_METRIC = "rmse"  # lower is better, chosen on VALIDATION set


def make_pipeline(estimator) -> Pipeline:
    # Imputer/scaler are fit on training data only (inside the pipeline) -> no leakage.
    return Pipeline([("imputer", SimpleImputer(strategy="median")),
                     ("scaler", StandardScaler()),
                     ("model", estimator)])


def candidates() -> dict:
    return {
        "baseline_mean": DummyRegressor(strategy="mean"),
        "ridge": Ridge(alpha=1.0, random_state=C.SEED),
        "random_forest": RandomForestRegressor(n_estimators=150, max_depth=16, min_samples_leaf=2,
                                               n_jobs=-1, random_state=C.SEED),
        "hist_gradient_boosting": HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08,
                                                                random_state=C.SEED),
    }


def split(df):
    X, y = df[C.FEATURES], df[C.TARGET]
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.4, random_state=C.SEED)
    X_val, X_te, y_val, y_te = train_test_split(X_tmp, y_tmp, test_size=0.5, random_state=C.SEED)
    return X_tr, X_val, X_te, y_tr, y_val, y_te


def run_eda(df):
    C.FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, 4)); df[C.TARGET].hist(bins=50, ax=ax)
    ax.set(title="Target distribution (x $100k)", xlabel=C.TARGET); fig.savefig(C.FIG_DIR / "target_distribution.png", dpi=110); plt.close(fig)
    fig, ax = plt.subplots(figsize=(8, 6)); sns.heatmap(df.corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
    ax.set_title("Correlation matrix"); fig.tight_layout(); fig.savefig(C.FIG_DIR / "correlation_heatmap.png", dpi=110); plt.close(fig)
    df[C.FEATURES].hist(bins=40, figsize=(12, 8)); plt.tight_layout()
    plt.savefig(C.FIG_DIR / "feature_histograms.png", dpi=100); plt.close("all")
    df.describe().T.to_csv(C.METRICS_DIR / "eda_summary.csv") if C.METRICS_DIR.exists() else None


def try_mlflow():
    try:
        import mlflow
        return mlflow
    except ImportError:
        return None


def main():
    C.METRICS_DIR.mkdir(parents=True, exist_ok=True); C.MODELS_DIR.mkdir(exist_ok=True)
    df = load_data()
    info = json.loads(C.DATA_INFO_PATH.read_text())
    run_eda(df)
    X_tr, X_val, X_te, y_tr, y_val, y_te = split(df)
    print(f"[train] train={len(X_tr)} val={len(X_val)} test={len(X_te)} | synthetic_data={info['is_synthetic']}")

    mlflow = try_mlflow()
    if mlflow:
        mlflow.set_tracking_uri(f"sqlite:///{C.MLFLOW_DB}")
        if mlflow.get_experiment_by_name(C.MLFLOW_EXPERIMENT) is None:
            mlflow.create_experiment(C.MLFLOW_EXPERIMENT, artifact_location=C.MLFLOW_ARTIFACTS.as_uri())
        mlflow.set_experiment(C.MLFLOW_EXPERIMENT)
    else:
        print("[train] WARNING: mlflow not installed -> tracking skipped (JSON results only).")

    results, fitted, run_ids = {}, {}, {}
    for name, est in candidates().items():
        pipe = make_pipeline(est).fit(X_tr, y_tr)
        res = {"val": regression_metrics(y_val, pipe.predict(X_val)),
               "test": regression_metrics(y_te, pipe.predict(X_te)),
               "train": regression_metrics(y_tr, pipe.predict(X_tr)),
               "params": {k: str(v) for k, v in est.get_params().items()}}
        results[name], fitted[name] = res, pipe
        print(f"[train] {name:24s} val_rmse={res['val']['rmse']:.4f} test_rmse={res['test']['rmse']:.4f} test_r2={res['test']['r2']:.4f}")
        if mlflow:
            with mlflow.start_run(run_name=name) as run:
                mlflow.log_params({"model": name, "seed": C.SEED, **res["params"]})
                mlflow.log_params({"dataset": info["name"], "is_synthetic": info["is_synthetic"], "n_rows": len(df)})
                for split_name in ("train", "val", "test"):
                    mlflow.log_metrics({f"{split_name}_{k}": v for k, v in res[split_name].items()})
                mlflow.log_artifact(str(C.DATA_INFO_PATH))
                run_ids[name] = run.info.run_id

    # Select best among non-baseline models on VALIDATION metric (test set untouched for selection)
    pool = {n: r for n, r in results.items() if not n.startswith("baseline")}
    best = min(pool, key=lambda n: pool[n]["val"][SELECTION_METRIC])
    best_pipe = fitted[best]
    plot_predictions(y_te.values, best_pipe.predict(X_te), best)

    version = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    reg_status = "mlflow not installed - not registered"
    if mlflow:
        try:
            from mlflow.models import infer_signature
            with mlflow.start_run(run_id=run_ids[best]):
                sig = infer_signature(X_tr.head(50), best_pipe.predict(X_tr.head(50)))
                mlflow.sklearn.log_model(best_pipe, name="model", signature=sig,
                                         registered_model_name=C.REGISTERED_MODEL_NAME)
                mlflow.set_tag("selected_best", "true")
            reg_status = f"registered as '{C.REGISTERED_MODEL_NAME}'"
        except Exception as exc:
            reg_status = f"registration FAILED: {exc}"
        print(f"[train] MLflow: {reg_status}")

    joblib.dump(best_pipe, C.MODEL_PATH)  # standalone artifact used by API/Docker
    meta = {"model_name": C.REGISTERED_MODEL_NAME, "version": version, "algorithm": best,
            "features": C.FEATURES, "target": C.TARGET, "target_units": "$100,000",
            "metrics_test": results[best]["test"], "metrics_val": results[best]["val"],
            "trained_with_synthetic_data": info["is_synthetic"], "dataset": info["name"],
            "sklearn_version": sklearn.__version__, "python_version": platform.python_version(),
            "mlflow_registration": reg_status, "trained_at": datetime.now(timezone.utc).isoformat()}
    C.MODEL_META_PATH.write_text(json.dumps(meta, indent=2))
    save_results({"selection_metric": f"val_{SELECTION_METRIC}", "best_model": best,
                  "models": results, "split_sizes": {"train": len(X_tr), "val": len(X_val), "test": len(X_te)}})
    print(f"[train] Best model: {best} -> saved {C.MODEL_PATH}")


if __name__ == "__main__":
    main()
