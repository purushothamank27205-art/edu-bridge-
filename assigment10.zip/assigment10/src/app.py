"""FastAPI prediction service. Model is loaded once at startup."""
import logging
import os
from contextlib import asynccontextmanager
from typing import List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from src.predict import HousePredictor

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("house-api")
state = {"predictor": None}


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        state["predictor"] = HousePredictor()
        log.info("Model loaded")
    except Exception:
        log.exception("Model failed to load")
    yield


app = FastAPI(title="House Price Prediction API", version="1.0.0", lifespan=lifespan)


class HouseFeatures(BaseModel):
    MedInc: float = Field(..., gt=0, le=20, description="Median income (x $10k)")
    HouseAge: float = Field(..., ge=0, le=100)
    AveRooms: float = Field(..., gt=0, le=100)
    AveBedrms: float = Field(..., gt=0, le=50)
    Population: float = Field(..., gt=0, le=100000)
    AveOccup: float = Field(..., gt=0, le=1000)
    Latitude: float = Field(..., ge=-90, le=90)
    Longitude: float = Field(..., ge=-180, le=180)

    model_config = {"json_schema_extra": {"example": {
        "MedInc": 5.0, "HouseAge": 20, "AveRooms": 5.5, "AveBedrms": 1.0,
        "Population": 1200, "AveOccup": 3.0, "Latitude": 37.8, "Longitude": -122.3}}}


class PredictionResponse(BaseModel):
    predicted_median_house_value_usd: float
    predicted_median_house_value_100k: float
    model_version: str


def _ready():
    if state["predictor"] is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    return state["predictor"]


@app.get("/")
def root():
    return {"name": "House Price Prediction API", "docs": "/docs", "endpoints": ["/health", "/model-info", "/predict"]}


@app.get("/health")
def health():
    ok = state["predictor"] is not None
    return {"status": "ok" if ok else "degraded", "model_loaded": ok}


@app.get("/model-info")
def model_info():
    return _ready().metadata


@app.post("/predict", response_model=PredictionResponse)
def predict(item: HouseFeatures):
    p = _ready()
    try:
        value = p.predict([item.model_dump()])[0]
    except Exception:
        log.exception("Prediction failed")
        raise HTTPException(status_code=500, detail="Prediction failed")
    return PredictionResponse(predicted_median_house_value_usd=round(value * 100000, 2),
                              predicted_median_house_value_100k=round(value, 4),
                              model_version=p.metadata.get("version", "unknown"))
