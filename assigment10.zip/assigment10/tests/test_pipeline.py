"""unittest-style tests (run with pytest OR `python -m unittest`)."""
import importlib.util
import json
import unittest

import numpy as np
import pandas as pd

from src import config as C
from src.data_preparation import load_data, make_synthetic, validate
from src.predict import HousePredictor
from src.train import candidates, make_pipeline, split

SAMPLE = {"MedInc": 5.0, "HouseAge": 20, "AveRooms": 5.5, "AveBedrms": 1.0,
          "Population": 1200, "AveOccup": 3.0, "Latitude": 37.8, "Longitude": -122.3}
HAS_API = all(importlib.util.find_spec(m) for m in ("fastapi", "httpx"))


class TestData(unittest.TestCase):
    def test_load_and_validate(self):
        df = load_data(); rep = validate(df)
        self.assertEqual(rep["missing_values"], 0)
        self.assertTrue(set(C.FEATURES + [C.TARGET]).issubset(df.columns))
        self.assertTrue(C.DATA_INFO_PATH.exists())

    def test_validation_rejects_missing_column(self):
        with self.assertRaises(ValueError):
            validate(make_synthetic(2000).drop(columns=["MedInc"]))


class TestTraining(unittest.TestCase):
    def test_pipeline_fit_no_leakage(self):
        df = make_synthetic(2000)
        X_tr, X_val, X_te, y_tr, *_ = split(df)
        pipe = make_pipeline(candidates()["ridge"]).fit(X_tr, y_tr)
        # scaler statistics must equal TRAIN-only statistics
        np.testing.assert_allclose(pipe.named_steps["scaler"].mean_, X_tr.mean().values, rtol=1e-6)
        self.assertEqual(len(pipe.predict(X_te)), len(X_te))

    def test_model_beats_baseline(self):
        res = json.loads((C.METRICS_DIR / "model_comparison.json").read_text())
        best = res["models"][res["best_model"]]["test"]["rmse"]
        self.assertLess(best, res["models"]["baseline_mean"]["test"]["rmse"])


class TestPredict(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = HousePredictor()

    def test_output_schema(self):
        out = self.p.predict([SAMPLE, SAMPLE])
        self.assertEqual(len(out), 2)
        self.assertTrue(all(isinstance(v, float) and np.isfinite(v) for v in out))

    def test_feature_order_is_enforced(self):
        shuffled = dict(reversed(list(SAMPLE.items())))
        self.assertEqual(self.p.predict([SAMPLE]), self.p.predict([shuffled]))

    def test_missing_feature_raises(self):
        bad = {k: v for k, v in SAMPLE.items() if k != "MedInc"}
        with self.assertRaises(KeyError):
            self.p.predict([bad])

    def test_metadata(self):
        self.assertEqual(self.p.metadata["features"], C.FEATURES)


@unittest.skipUnless(HAS_API, "fastapi/httpx not installed")
class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from src.app import app
        cls.cm = TestClient(app); cls.client = cls.cm.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.cm.__exit__(None, None, None)

    def test_health_root_info(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertTrue(self.client.get("/health").json()["model_loaded"])
        self.assertIn("features", self.client.get("/model-info").json())

    def test_predict_matches_standalone(self):
        r = self.client.post("/predict", json=SAMPLE)
        self.assertEqual(r.status_code, 200)
        expected = HousePredictor().predict([SAMPLE])[0]
        self.assertAlmostEqual(r.json()["predicted_median_house_value_100k"], expected, places=3)

    def test_missing_and_invalid_inputs(self):
        bad = {k: v for k, v in SAMPLE.items() if k != "MedInc"}
        self.assertEqual(self.client.post("/predict", json=bad).status_code, 422)
        self.assertEqual(self.client.post("/predict", json={**SAMPLE, "MedInc": -1}).status_code, 422)
        self.assertEqual(self.client.post("/predict", json={**SAMPLE, "HouseAge": "old"}).status_code, 422)


if __name__ == "__main__":
    unittest.main()
