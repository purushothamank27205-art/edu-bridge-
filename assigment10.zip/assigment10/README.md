# House Price Prediction – End-to-End ML Project

Predicts median house value (target `MedHouseVal`, units of $100,000) from 8 numeric features
(`MedInc, HouseAge, AveRooms, AveBedrms, Population, AveOccup, Latitude, Longitude`).
Regression task. Stack: scikit-learn, MLflow, FastAPI, Docker, unittest/pytest.

## ⚠️ Verification status (honest report)
Built in a sandbox with **no internet, no Docker**, and no MLflow/FastAPI/pytest installed.

| Step | Status |
|---|---|
| Data prep + validation | ✅ ran – but used **SYNTHETIC data** (download failed). `data/DATASET_INFO.json` has `is_synthetic: true` |
| EDA plots, training, evaluation, standalone prediction | ✅ ran |
| Tests (unittest) | ✅ 8 passed, 3 API tests skipped (FastAPI missing) |
| MLflow tracking + registry | ⚠️ code written, **not executed** |
| FastAPI service + API tests | ⚠️ code written, compiles, **not executed** |
| Docker build/run | ⚠️ Dockerfile written, **not built** |

Run `./run_all.sh` on your machine (with internet) to get real data and verify everything.
Metrics below are on synthetic data and are NOT real-world performance.

## Observed results (synthetic data, test set, n=1200)
| Model | Test RMSE | Test R² |
|---|---|---|
| baseline_mean | 0.983 | -0.002 |
| ridge | 0.449 | 0.791 |
| **random_forest (selected)** | **0.357** | **0.868** |
| hist_gradient_boosting | 0.363 | 0.863 |

Split 60/20/20 (seed 42). Best model chosen on **validation RMSE**; test set only for reporting.

## Quick start
```bash
pip install -r requirements.txt
./run_all.sh            # data -> train -> evaluate -> tests -> docker (if available)
make serve              # API at http://localhost:8000/docs
```
Makefile targets: `setup data train evaluate serve test docker-build docker-run all`.

## Real dataset
California Housing (StatLib, Pace & Barry 1997), public domain, via
`sklearn.datasets.fetch_california_housing`. To replace synthetic data: `python -m src.data_preparation --force`, then `make train`.

## API
- `GET /`, `GET /health`, `GET /model-info`
- `POST /predict`
```json
{"MedInc":5.0,"HouseAge":20,"AveRooms":5.5,"AveBedrms":1.0,"Population":1200,"AveOccup":3.0,"Latitude":37.8,"Longitude":-122.3}
```
Response: `{"predicted_median_house_value_usd":..., "predicted_median_house_value_100k":..., "model_version":"..."}`
Invalid/missing fields → HTTP 422.

## MLflow
`src/train.py` uses a SQLite store (`mlflow.db`) + `mlruns/` artifacts, experiment `house-price-prediction`,
logs params/metrics/signature and registers `house-price-model`. The API uses `models/model.joblib`
(no MLflow server needed at inference time).

## Docker
```bash
make docker-build && make docker-run
curl localhost:8000/health
```
Runs as non-root, listens on 0.0.0.0, port via `PORT` env var, model baked into image.

## Structure
`src/` (config, data_preparation, train, evaluate, predict, app) · `tests/` · `models/` · `reports/figures|metrics` · `Dockerfile` · `Makefile` · `run_all.sh`

## Limitations
Synthetic-data results; no hyperparameter search; California-only geography; predictions are estimates, not guarantees.
