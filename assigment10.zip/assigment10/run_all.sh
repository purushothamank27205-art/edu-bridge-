#!/usr/bin/env bash
# One-command workflow: data -> train -> evaluate -> tests -> (docker if available)
set -euo pipefail
cd "$(dirname "$0")"
python3 -m src.data_preparation
python3 -m src.train
python3 -m src.evaluate
python3 -m pytest -v tests 2>/dev/null || python3 -m unittest discover -v -s tests -t .
if command -v docker >/dev/null; then
  docker build -t house-price-api:1.0.0 .
  docker run -d --rm --name hp-api -p 8000:8000 house-price-api:1.0.0
  for i in $(seq 1 20); do curl -sf localhost:8000/health && break || sleep 1; done
  curl -s -X POST localhost:8000/predict -H 'Content-Type: application/json' \
    -d '{"MedInc":5,"HouseAge":20,"AveRooms":5.5,"AveBedrms":1,"Population":1200,"AveOccup":3,"Latitude":37.8,"Longitude":-122.3}'
  docker stop hp-api
else
  echo "Docker not available - skipped container steps."
fi
