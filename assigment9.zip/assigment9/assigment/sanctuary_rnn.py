"""Animal sanctuary visitor forecasting with a GRU (PyTorch).
Predicts the next 7 days of visitors from the past 28 days.
Uses synthetic data by default; to use your own, set CSV_PATH to a file with columns:
date, visitors, temperature   (one row per day).
Run: python sanctuary_rnn.py      Needs: pip install torch numpy pandas matplotlib
"""
import numpy as np, pandas as pd, torch, torch.nn as nn
import matplotlib.pyplot as plt

CSV_PATH = None            # e.g. "sanctuary.csv"
WINDOW, HORIZON = 28, 7
HIDDEN, LAYERS, EPOCHS, LR, BS = 64, 2, 40, 5e-3, 32
torch.manual_seed(0); np.random.seed(0)


def make_data(days=3 * 365):
    d = pd.date_range("2022-01-01", periods=days)
    doy = d.dayofyear.values
    temp = 15 + 12 * np.sin(2 * np.pi * (doy - 100) / 365) + np.random.randn(days) * 3
    weekend = (d.dayofweek >= 5).astype(float)
    visitors = (60 + 70 * weekend + 2.5 * np.clip(temp, 0, 28)
                - 4 * np.clip(temp - 30, 0, None) + np.random.randn(days) * 12)
    return pd.DataFrame({"date": d, "visitors": np.clip(visitors, 0, None), "temperature": temp})


df = pd.read_csv(CSV_PATH, parse_dates=["date"]) if CSV_PATH else make_data()
df["is_weekend"] = (df["date"].dt.dayofweek >= 5).astype(float)
df["doy_sin"] = np.sin(2 * np.pi * df["date"].dt.dayofyear / 365)
df["doy_cos"] = np.cos(2 * np.pi * df["date"].dt.dayofyear / 365)
feats = ["visitors", "temperature", "is_weekend", "doy_sin", "doy_cos"]

split = int(0.8 * len(df))                       # chronological split, no shuffling
mu, sd = df[feats][:split].mean(), df[feats][:split].std()
Z = ((df[feats] - mu) / sd).values.astype("float32")
v_mu, v_sd = mu["visitors"], sd["visitors"]


def windows(lo, hi):
    X, Y = [], []
    for i in range(lo, hi - WINDOW - HORIZON + 1):
        X.append(Z[i:i + WINDOW]); Y.append(Z[i + WINDOW:i + WINDOW + HORIZON, 0])
    return torch.tensor(np.stack(X)), torch.tensor(np.stack(Y))


Xtr, Ytr = windows(0, split)
Xte, Yte = windows(split - WINDOW, len(df))      # test windows may look back into train


class Forecaster(nn.Module):
    def __init__(self):
        super().__init__()
        self.gru = nn.GRU(len(feats), HIDDEN, LAYERS, batch_first=True, dropout=0.1)
        self.fc = nn.Linear(HIDDEN, HORIZON)

    def forward(self, x):
        return self.fc(self.gru(x)[0][:, -1])


model = Forecaster()
opt = torch.optim.Adam(model.parameters(), lr=LR)
loss_fn = nn.L1Loss()
for ep in range(EPOCHS):
    model.train()
    for idx in torch.randperm(len(Xtr)).split(BS):
        opt.zero_grad(); loss = loss_fn(model(Xtr[idx]), Ytr[idx]); loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
    if (ep + 1) % 5 == 0:
        model.eval()
        with torch.no_grad():
            print(f"epoch {ep+1:2d}  train MAE {loss.item()*v_sd:6.1f}  "
                  f"test MAE {loss_fn(model(Xte), Yte).item()*v_sd:6.1f} visitors")

model.eval()
with torch.no_grad():
    pred = model(Xte).numpy() * v_sd + v_mu
true = Yte.numpy() * v_sd + v_mu
naive = Xte[:, -7:, 0].numpy() * v_sd + v_mu     # baseline: repeat last week
print(f"\nGRU MAE: {np.abs(pred - true).mean():.1f}   "
      f"'same as last week' baseline MAE: {np.abs(naive - true).mean():.1f}")

# Plot day-1-ahead forecasts across the test period
plt.figure(figsize=(10, 4))
plt.plot(true[:, 0], label="actual"); plt.plot(pred[:, 0], label="GRU (1 day ahead)")
plt.title("Sanctuary daily visitors - test period"); plt.xlabel("day"); plt.legend()
plt.tight_layout(); plt.savefig("sanctuary_forecast.png"); print("Saved sanctuary_forecast.png")

# Forecast the next 7 days from the most recent 28
last = torch.tensor(Z[-WINDOW:]).unsqueeze(0)
with torch.no_grad():
    nxt = model(last).numpy()[0] * v_sd + v_mu
print("Next 7 days forecast:", np.round(nxt).astype(int))
torch.save(model.state_dict(), "sanctuary_gru.pt")
