import streamlit as st, torch
from PIL import Image, ImageOps
from torchvision import transforms
from model import SimpleCNN

st.title("Handwritten Digit Recognizer (CNN)")

@st.cache_resource
def load():
    m = SimpleCNN()
    m.load_state_dict(torch.load("mnist_cnn.pth", map_location="cpu"))
    return m.eval()

file = st.file_uploader("Upload a digit image (dark digit on white is fine)", type=["png", "jpg", "jpeg"])
if file:
    img = Image.open(file).convert("L")
    st.image(img, width=150)
    img = ImageOps.invert(img)  # MNIST is white digit on black
    x = transforms.Compose([transforms.Resize((28, 28)), transforms.ToTensor()])(img).unsqueeze(0)
    with torch.no_grad():
        probs = torch.softmax(load()(x), dim=1)[0]
    st.subheader(f"Prediction: {probs.argmax().item()}  ({probs.max().item()*100:.1f}%)")
    st.bar_chart(probs.numpy())
