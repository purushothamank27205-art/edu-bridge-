import torch, torch.nn as nn
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from model import SimpleCNN

tf = transforms.ToTensor()
train_ds = datasets.MNIST("data", train=True, download=True, transform=tf)
test_ds = datasets.MNIST("data", train=False, download=True, transform=tf)
train_dl = DataLoader(train_ds, batch_size=64, shuffle=True)
test_dl = DataLoader(test_ds, batch_size=256)

model = SimpleCNN()
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
loss_fn = nn.CrossEntropyLoss()

for epoch in range(3):
    model.train()
    for x, y in train_dl:
        opt.zero_grad()
        loss_fn(model(x), y).backward()
        opt.step()

    model.eval()
    correct = 0
    with torch.no_grad():
        for x, y in test_dl:
            correct += (model(x).argmax(1) == y).sum().item()
    print(f"Epoch {epoch+1}: test accuracy = {correct/len(test_ds)*100:.2f}%")

torch.save(model.state_dict(), "mnist_cnn.pth")
print("Saved mnist_cnn.pth")
