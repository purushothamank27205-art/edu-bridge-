"""MLflow project: network flow classification (benign / DDoS / port scan).
Trains several models on flow features, logs everything to MLflow, registers the best.
Uses synthetic flow data; to use a real dataset (e.g. CICIDS2017), set CSV_PATH and LABEL_COL.
Run:  python mlflow_network_flow.py
View: mlflow ui --backend-store-uri sqlite:///mlflow.db   (open http://127.0.0.1:5000)
Needs: pip install mlflow scikit-learn pandas numpy matplotlib
"""
import numpy as np, pandas as pd, mlflow, mlflow.sklearn
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mlflow.tracking import MlflowClient
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

CSV_PATH, LABEL_COL = None, "label"
rng = np.random.default_rng(0)


def make_flows(n=6000):
    """Synthetic flows: 0 = benign, 1 = ddos, 2 = portscan."""
    rows = []
    for label, frac in [(0, 0.6), (1, 0.2), (2, 0.2)]:
        m = int(n * frac)
        if label == 0:      # normal browsing / transfers
            dur = rng.exponential(2.0, m); fp = rng.poisson(20, m) + 1; bp = rng.poisson(18, m) + 1
            fb = fp * rng.normal(500, 150, m).clip(40); bb = bp * rng.normal(600, 200, m).clip(40)
            syn = rng.poisson(1, m); port = rng.choice([80, 443, 53, 22, 8080], m)
        elif label == 1:    # flood: very short, many packets, little response
            dur = rng.exponential(0.3, m); fp = rng.poisson(300, m) + 1; bp = rng.poisson(2, m)
            fb = fp * rng.normal(70, 15, m).clip(40); bb = bp * 60.0
            syn = rng.poisson(40, m); port = rng.choice([80, 443], m)
        else:               # scan: tiny flows to many different ports
            dur = rng.exponential(0.05, m); fp = rng.poisson(2, m) + 1; bp = rng.poisson(1, m)
            fb = fp * rng.normal(44, 5, m).clip(40); bb = bp * 40.0
            syn = rng.poisson(2, m) + 1; port = rng.integers(1, 65535, m)
        rows.append(pd.DataFrame({
            "duration": dur, "fwd_packets": fp, "bwd_packets": bp, "fwd_bytes": fb, "bwd_bytes": bb,
            "pkts_per_sec": (fp + bp) / (dur + 1e-3), "bytes_per_sec": (fb + bb) / (dur + 1e-3),
            "avg_pkt_size": (fb + bb) / (fp + bp + 1e-3), "syn_count": syn, "dst_port": port, "label": label}))
    return pd.concat(rows).sample(frac=1, random_state=0).reset_index(drop=True)


df = pd.read_csv(CSV_PATH) if CSV_PATH else make_flows()
y = df[LABEL_COL] if CSV_PATH else df["label"]
X = df.drop(columns=[LABEL_COL if CSV_PATH else "label"])
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)

mlflow.set_tracking_uri("sqlite:///mlflow.db")
mlflow.set_experiment("network-flow-ids")

candidates = [
    ("logreg", lambda p: make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, **p)), [{"C": 0.1}, {"C": 10}]),
    ("random_forest", lambda p: RandomForestClassifier(random_state=0, n_jobs=-1, **p),
     [{"n_estimators": 100, "max_depth": 6}, {"n_estimators": 300, "max_depth": None}]),
    ("grad_boost", lambda p: GradientBoostingClassifier(random_state=0, **p),
     [{"n_estimators": 100, "learning_rate": 0.1}, {"n_estimators": 200, "learning_rate": 0.05}]),
]


def log_model(model):
    try:
        return mlflow.sklearn.log_model(model, name="model", serialization_format="cloudpickle")           # MLflow 3.x
    except TypeError:
        return mlflow.sklearn.log_model(model, artifact_path="model", serialization_format="cloudpickle")  # MLflow 2.x


best = {"f1": -1}
for kind, build, grid in candidates:
    for params in grid:
        with mlflow.start_run(run_name=f"{kind}-{params}"):
            model = build(params).fit(Xtr, ytr)
            pred = model.predict(Xte)
            acc, f1 = accuracy_score(yte, pred), f1_score(yte, pred, average="macro")
            mlflow.log_param("model", kind); mlflow.log_params(params)
            mlflow.log_param("n_features", X.shape[1])
            mlflow.log_metrics({"accuracy": acc, "f1_macro": f1})
            fig, ax = plt.subplots(figsize=(5, 4))
            ConfusionMatrixDisplay(confusion_matrix(yte, pred),
                                   display_labels=["benign", "ddos", "scan"]).plot(ax=ax, colorbar=False)
            mlflow.log_figure(fig, "confusion_matrix.png"); plt.close(fig)
            info = log_model(model)
            print(f"{kind:14s} {str(params):45s} acc={acc:.3f} f1={f1:.3f}")
            if f1 > best["f1"]:
                best = {"f1": f1, "uri": info.model_uri, "name": f"{kind}-{params}"}

mv = mlflow.register_model(best["uri"], "network-flow-classifier")
MlflowClient().set_registered_model_alias("network-flow-classifier", "champion", mv.version)
print(f"\nBest: {best['name']} (f1={best['f1']:.3f}) registered as network-flow-classifier v{mv.version}")

# Load the registered model and classify a few unseen flows
champ = mlflow.sklearn.load_model("models:/network-flow-classifier@champion")
names = {0: "benign", 1: "ddos", 2: "portscan"}
print("Sample predictions:", [names[int(p)] for p in champ.predict(Xte.head(8))],
      "| actual:", [names[int(a)] for a in yte.head(8)])
